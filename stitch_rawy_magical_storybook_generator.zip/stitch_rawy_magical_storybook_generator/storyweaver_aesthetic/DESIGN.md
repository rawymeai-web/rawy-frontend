---
name: Storyweaver Aesthetic
colors:
  surface: '#f9f9ff'
  surface-dim: '#cadaff'
  surface-bright: '#f9f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f1f3ff'
  surface-container: '#e8edff'
  surface-container-high: '#e0e8ff'
  surface-container-highest: '#d7e2ff'
  on-surface: '#001a40'
  on-surface-variant: '#554339'
  inverse-surface: '#193056'
  inverse-on-surface: '#edf0ff'
  outline: '#887368'
  outline-variant: '#dbc1b5'
  surface-tint: '#994709'
  primary: '#994709'
  on-primary: '#ffffff'
  primary-container: '#f78f50'
  on-primary-container: '#692c00'
  inverse-primary: '#ffb68e'
  secondary: '#006b5d'
  on-secondary: '#ffffff'
  secondary-container: '#90f4e0'
  on-secondary-container: '#007163'
  tertiary: '#775a00'
  on-tertiary: '#ffffff'
  tertiary-container: '#cca53d'
  on-tertiary-container: '#503c00'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdbc9'
  primary-fixed-dim: '#ffb68e'
  on-primary-fixed: '#331200'
  on-primary-fixed-variant: '#763300'
  secondary-fixed: '#90f4e0'
  secondary-fixed-dim: '#74d8c5'
  on-secondary-fixed: '#00201b'
  on-secondary-fixed-variant: '#005046'
  tertiary-fixed: '#ffdf97'
  tertiary-fixed-dim: '#ecc156'
  on-tertiary-fixed: '#251a00'
  on-tertiary-fixed-variant: '#5a4400'
  background: '#f9f9ff'
  on-background: '#001a40'
  surface-variant: '#d7e2ff'
typography:
  h1:
    fontFamily: Plus Jakarta Sans
    fontSize: 48px
    fontWeight: '800'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  h2:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.3'
  h3:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: '1.4'
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '500'
    lineHeight: '1.6'
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  label-caps:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: 0.05em
rounded:
  sm: 0.5rem
  DEFAULT: 1rem
  md: 1.5rem
  lg: 2rem
  xl: 3rem
  full: 9999px
spacing:
  unit: 8px
  container-max: 1200px
  gutter: 24px
  margin-mobile: 20px
  margin-desktop: 40px
---

## Brand & Style
The brand personality is **Modern, Magical, and Premium**. This design system bridges the gap between a playful childhood imagination and a high-end, sophisticated digital experience. It is designed to evoke a sense of wonder, safety, and creative limitless possibilities.

The visual direction utilizes a refined **Glassmorphism** style. It leans into the "tactile digital" space—where elements feel like polished physical objects floating over a soft, organic background. The interface remains spacious and clean to ensure that the AI-generated stories and illustrations remain the primary hero of the experience. Floating animated blobs in the brand's secondary colors move subtly in the background to provide a sense of life and "magic" without distracting from the functional UI.

## Colors
The palette is rooted in a warm, off-white "paper" background to signify the storytelling medium. 
- **Coral (#F78F50)** acts as the energetic primary action color.
- **Teal Green (#4EB4A2)** and **Soft Yellow (#F4C95D)** provide a playful, multi-colored spectrum for categorization and secondary accents.
- **Deep Navy (#243A61)** is reserved for text and high-contrast iconography to ensure legibility and a premium "ink-on-paper" feel.
- **Glass** elements use a semi-transparent white with a high-diffusion background blur (20px-30px) to create depth.

## Typography
This design system utilizes **Plus Jakarta Sans** (as the closest high-end equivalent to Nunito’s rounded, friendly energy) for English and **Tajawal** for Arabic. Both fonts share a geometric yet approachable construction. 

Headlines should be bold and weighted to feel impactful, while body text maintains generous line height for readability, especially for younger audiences and parents reading together. For the Arabic script, ensure the baseline is balanced with the English counterparts, as Tajawal's x-height is naturally distinct.

## Layout & Spacing
The system employs a **Fixed Grid** for desktop and a **Fluid Grid** for mobile devices. 
- Desktop: 12-column layout with a 24px gutter.
- Mobile: 4-column layout with 16px gutters.

The spacing rhythm is built on an 8px base unit. Wide margins and generous padding within glass containers are essential to maintain the "Spacious and Clean" aesthetic. Elements should never feel cramped; the layout should breathe, mirroring the open pages of an illustrated book.

## Elevation & Depth
Depth is achieved through a combination of **Glassmorphism** and **Ambient Shadows**. 

1. **The Base:** The #FFF9F0 paper background.
2. **The Float:** Glass layers (rgba 255, 255, 255, 0.45) sit above the background with a 32px background blur.
3. **The Shadow:** Use soft, extra-diffused shadows for elevated components. Example: `0px 20px 40px rgba(36, 58, 97, 0.08)`. Shadows should be slightly tinted with the Deep Navy (#243A61) color to feel natural rather than gray.
4. **The Glow:** Background blobs use soft-light blending modes to create a layered, atmospheric depth.

## Shapes
The shape language is defined by extreme softness. A **rounded-3xl (24px to 32px)** corner radius is the standard for cards, buttons, and input fields. This high degree of roundedness removes "sharpness" and visual tension, making the product feel safe and inviting for families. Interactive elements like buttons should often use "full" pill-shaping to distinguish them from container cards.

## Components
- **Primary Buttons:** Pill-shaped, Primary Coral (#F78F50) fill with white text. Apply a subtle inner light glow (top-down) to give a 3D "squishy" feel.
- **Glass Cards:** 32px corner radius, Glass fill, and a 1.5px semi-transparent white border. This border acts as a "highlight" edge to separate the glass from the paper background.
- **Input Fields:** Large, 24px rounded corners, background color set to a slightly darker shade of the paper (#F5EFE6) or clear glass. Deep Navy text for input.
- **Floating Blobs:** Non-interactive, blurred SVG shapes in Teal Green and Soft Yellow that animate slowly (pulse and drift) in the background.
- **Story Progress Bar:** A thick, Teal Green track with a Soft Yellow "sparkle" or star icon as the progress indicator.
- **Chips/Tags:** Small pill-shaped containers using the Teal Green or Soft Yellow with 10% opacity fills and 100% opacity text for a soft, premium categorized look.